
This program has been tested on Windows 10.

To use this program, run the traveller_planetary_tc_with_populations.exe file.

If a file is reported missing, such as MSVCP71.dll, copy the file to your C:\Windows\System32 folder.  Then run again.


-Shawn
shawndriscoll@hotmail.com






The Traveller game in all forms is owned by Far Future Enterprises. Copyright 1977 - 2018 Far Future Enterprises. Traveller is a registered trademark of Far Future Enterprises.